from flask import Flask, render_template, request
import pickle

def clean_text1(text):
    text = str(text)
    words = re.sub(r"(@[A-Za-z0-9]+)|([^0-9A-Za-z \t])|(\w+:\/\/\S+)|^rt|http.+?", " ", text)
    pattern = r"[\d]"
    words = re.sub(pattern, '', words)
    words = words.lower()
    final_words = [wnl().lemmatize(word) for word in words.split()]
    final_words = ' '.join(final_words)
    return final_words


model = pickle.load(open('red.pkl', 'rb'))

app = Flask(__name__, template_folder='template')


@app.route('/')
def main():
    return render_template('temp.html')


@app.route('/predict', methods=['POST'])
def home():
    comment = request.form['']
    return


if __name__ == "__main__":
    app.run(debug=True)